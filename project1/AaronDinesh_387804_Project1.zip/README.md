Run instructions for cgs.py, choleskyQR.py and tsqr.py. Each run scipt is parametrized by the run number (this is used for naming the file) and the column number (this is passed to the python script for selecting the number of columns). 

You can run the code using the command:
1) sbatch cgs.run #PUT_RUN_NUMBER_HERE #PUT_COL_NUMBER_HERE
2) sbatch choleskyQR.run #PUT_RUN_NUMBER_HERE #PUT_COL_NUMBER_HERE
3) sbatch tsqr.run #PUT_RUN_NUMBER_HERE #PUT_COL_NUMBER_HERE
